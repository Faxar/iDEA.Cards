package com.company;

/**
 * Created by vassili.holenev on 1.06.2016.
 */
public class DamageSpell extends Spell {
    private int power;

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }
}
