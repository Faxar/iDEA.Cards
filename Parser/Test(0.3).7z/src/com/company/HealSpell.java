package com.company;

/**
 * Created by vassili.holenev on 1.06.2016.
 */
public class HealSpell extends Spell {
    private int heal;

    public int getHeal() {
        return heal;
    }

    public void setHeal(int heal) {
        this.heal = heal;
    }
}
