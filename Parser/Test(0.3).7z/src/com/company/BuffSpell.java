package com.company;

/**
 * Created by vassili.holenev on 1.06.2016.
 */
public class BuffSpell extends Spell {
    private int modificator;

    public int getModificator() {
        return modificator;
    }

    public void setModificator(int modificator) {
        this.modificator = modificator;
    }
}
